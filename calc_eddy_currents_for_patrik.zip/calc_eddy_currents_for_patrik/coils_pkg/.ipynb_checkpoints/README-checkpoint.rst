``coils`` -- tools for field, eddy-current and (mutual) inductance calculations
===============================================================================

The ``coils`` module provide tools for computing electromagnetic problems. In
particular, magnetic fields and inductive coupling as well as eddy currents in
ohmic conductors is considered. 

This is not a release version, but more of a collection of random code.

Any feedback or suggestions are very welcome: koos.zevenhoven@aalto.fi.

Getting Started
===============

Requirements
------------

* Python 3.4 (May work with older versions, but no official support)

Installation
------------

The package can be installed with ``pip`` (make sure you have it installed):

.. code-block:: bash

    pip3 install git+http://github.com/k7hoven/coils

Or if your default python is Python 3:

.. code-block:: bash

    pip install git+http://github.com/k7hoven/coils


Basic Usage
===========

Sorry, no docs at the moment. This is not for redistribution.

