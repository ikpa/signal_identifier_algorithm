# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.open_gl_hardware_selector import OpenGLHardwareSelector


class PHardwareSelector(OpenGLHardwareSelector):
    """
    PHardwareSelector - HardwareSelector useful for parallel
    rendering.
    
    Superclass: OpenGLHardwareSelector
    
    PHardwareSelector is a HardwareSelector that is parallel aware.
    It relies on the fact that the application is going to use some other
    mechanism to ensure that renders are synchronized among windows on
    all processes. The synchronization happens from the root node. When
    the root node renders, all processes render. Only
    PHardwareSelector instance on the root node triggers the renders.
    All other processes, simply listen to the start_event fired and
    beginning of the render to ensure that HardwareSelector's
    current_pass is updated appropriately.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkPHardwareSelector, obj, update, **traits)
    
    process_is_root = tvtk_base.false_bool_trait(desc=\
        """
        Set/Get the is the root process. The root processes is the only
        processes which has the composited result and hence the only
        processes that capture buffers and builds selected list ids.
        """
    )

    def _process_is_root_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetProcessIsRoot,
                        self.process_is_root_)

    _updateable_traits_ = \
    (('process_is_root', 'GetProcessIsRoot'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('actor_pass_only', 'GetActorPassOnly'), ('area', 'GetArea'),
    ('capture_z_values', 'GetCaptureZValues'), ('field_association',
    'GetFieldAssociation'), ('process_id', 'GetProcessID'),
    ('prop_color_value', 'GetPropColorValue'),
    ('use_process_id_from_data', 'GetUseProcessIdFromData'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ('prop_color_value',)
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'process_is_root',
    'actor_pass_only', 'area', 'capture_z_values', 'field_association',
    'process_id', 'prop_color_value', 'use_process_id_from_data'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(PHardwareSelector, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit PHardwareSelector properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['process_is_root'], [], ['actor_pass_only', 'area',
            'capture_z_values', 'field_association', 'process_id',
            'prop_color_value', 'use_process_id_from_data']),
            title='Edit PHardwareSelector properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit PHardwareSelector properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

